1. Convert .ipynb files to .py

	jupyter nbconvert --to script afile.ipynb 
	jupyter nbconvert --to script efile.ipynb 

2. Evaluate

	python evaluate.py afile.py efile.py marksMapfile.csv marksOutfile.csv

Inputs needed:
  afile         (.py) answers given by students
  efile         (.py) evaluation tests
  marksMapfile  (.csv) question to be given to students

Output:
  marksOutfile  (.csv) marks obtained by the students

