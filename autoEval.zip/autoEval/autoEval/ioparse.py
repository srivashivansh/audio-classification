'''
Written by Vipul Arora - June 2019
MADHAV lab
Department of Electrical Engineering
IIT Kanpur

This version released on 9th Nov 2020
'''

import numpy as np

def parseBeginStr(line):
	"""
	### BEGIN - 5 MARKS 
	"""
	print(line)
	tokens = line.split("### BEGIN - ")
	assert len(tokens[0].strip())==0, "### BEGIN should have nothing before it; found %s"%line

	substr = tokens[1].split(" MARKS")
	assert len(substr)==1 or len(substr[1].strip())==0, " MARKS should have nothing after it; found %s"%stbstr
	marks = int(substr[0])
	yourCodeHereStr = line.replace("BEGIN", "WRITE YOUR CODE HERE")
	return marks, yourCodeHereStr

def parseFuncStr(line):
	"""
	def funcName():
	"""
	line = line.strip()
	tokens = line.split("def ")
	assert tokens[0]=="", tokens
	line = tokens[1]
	funcName = line.split("(")[0]
	return funcName

def marksMap_read(marksMapfile):
	"""
	funcName,marks
	E.g.: addNumbers,5
	"""
	funcNames_=[]
	marks_=[]
	with open(marksMapfile) as fid:
		for line in fid:
			tokens = line.strip().split(',')
			assert len(tokens)==2, tokens
			funcNames_.append(tokens[0])
			marks_.append(float(tokens[1]))
	assert len(set(funcNames_)) == len(marks_), [funcNames_, marks_]
	return funcNames_, marks_

def marksMap_write(marksMapfile, funcNames_, marks_):
	with open(marksMapfile,"w") as mapfid:
		assert len(set(funcNames_))==len(marks_), ["funcNames repeated ...", funcNames_, marks_]
		for i in range(len(funcNames_)):
			print("%s,%.1f"%(funcNames_[i], marks_[i]), file=mapfid)
		marks_ = np.array(marks_)
		print("TOTAL MARKS: %.1f"%np.sum(marks_))
	return
