'''
Written by Vipul Arora - June 2019
MADHAV lab
Department of Electrical Engineering
IIT Kanpur

This version released on 9th Nov 2020
'''

import argparse
import pdb
import os, sys, json
import importlib.util
from ioparse import marksMap_read, marksMap_write
import traceback
'''
- Test cases:
	- 0 <= marksfraction <= 1
	- Or don't return marksfraction

	def getSquare(mod):
		marks = 0
		x = -5
		y = mod.getSquare(x)
		if np.sign(y) == np.sign(x*x):
			marks += 0.5
		if np.abs(y)==np.abs(x*x):
			marks += 0.5
		return marks
	def getCube(mod):
		y = mod.getCube(x)
		assert y==x*x*x, [y,'not equal to',x*x*x]
		return
'''
if __name__=="__main__":
	parser = argparse.ArgumentParser(description='Evaluate afile against efile and gives marks as in marksMapfile')
	parser.add_argument('afile', help="(.py) answers given by students")
	parser.add_argument('efile', help="(.py) evaluation tests")	
	parser.add_argument('marksMapfile', help="(.csv) question to be given to students")
	parser.add_argument('marksOutfile', help="(.csv) write marks obtained by the students")	
	args = parser.parse_args()

	# Read Answers from student
	print("STUDENT file: %s"%args.afile)
	spec = importlib.util.spec_from_file_location("module", args.afile)
	amod = importlib.util.module_from_spec(spec)
	spec.loader.exec_module(amod)

	# Marks
	funcNames_, marks_ = marksMap_read(args.marksMapfile)

	# Read Test
	print("TEST file: %s"%args.efile)
	spec = importlib.util.spec_from_file_location("module", args.efile)
	emod = importlib.util.module_from_spec(spec)
	spec.loader.exec_module(emod)

	# Evaluate
	marksObtd_ = []
	for i in range(len(funcNames_)):
		print("QUE: %s"%funcNames_[i])
		marksObtd_.append( marks_[i] )  # full marks
		try:
			marksfraction = getattr(emod, funcNames_[i])(amod)
			if marksfraction is None:
				marksfraction = 1
			marksObtd_[-1] *= marksfraction
		except Exception as err: # if err in evaluation, give 0 marks
			#exc_type, exc_obj, exc_tb = sys.exc_info()
			#fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			#print(exc_type, fname, exc_tb)
			print(traceback.format_exc())
			print(err)
			marksObtd_[-1] = 0 

	# Write Obtained Marks
	marksMap_write(args.marksOutfile, funcNames_, marksObtd_)
